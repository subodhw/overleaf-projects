See the homepage at http://speedata.github.io/luaqrcode/
for more information.

Special thanks to
  Wes Garrison